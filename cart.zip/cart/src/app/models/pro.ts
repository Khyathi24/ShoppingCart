export interface Product {
    title: any;
    price: number;
    category: any;
    imageUrl: any;
    quantity:number;
   id:any;
   visited:boolean;
}

